import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Person } from './person';
@Injectable({
  providedIn: 'root'
})
export class PersonService {
   baseURL :string = 'HTTP://localhost:3000/';
   headers = {'content-type':'application/json'};
  constructor(private http:HttpClient) {}

  getPeople():Observable<any>{
      return this.http.get(this.baseURL +'people');
  }

  addPerson(person:Person):Observable<any>{
    let body = JSON.stringify(person)
    return this.http.post(this.baseURL + 'people' , body ,{headers:this.headers})
  }

  updatePerson(person:Person):Observable<any>{
    let body = JSON.stringify(person)
    return this.http.put(this.baseURL + 'people/' +person.id , body ,{headers:this.headers})
  }

  deletePerson(person:Person):Observable<any>{
    return this.http.delete(this.baseURL +'people/'+ person.id);
  }

}
