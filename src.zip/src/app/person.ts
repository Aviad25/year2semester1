export class Person{
  id:number=0
  name:string=""
  age:number=0
}
